/*
 * B 站 CDN 线路 —— ISOLATED world 桥接脚本
 *
 * 职责：
 *  1) 读取 chrome.storage.local 设定，写进同源 localStorage（供 MAIN 同步读取），
 *     并用 postMessage 推给 MAIN world。
 *  2) 监听 chrome.storage 变更 → 即时同步给 MAIN。
 *  3) 收集 MAIN 回报的 debug 快照，回应 popup 的查询。
 *  4) 問題回報：把 MAIN 的事件日誌／採樣轉給 background 存起來、每 5 秒存一份快照；
 *     回報頁（獨立視窗）開啟時回應「此刻」的快照（CDN_SWITCHER_GET_DEBUG_FRESH）。
 *  5) 節點清單（伺服器下發，見 cdn-list.js）：還沒拿到清單時推給 MAIN 的 enabled 一律是 false（擴充不啟用、不改寫任何網址）；
 *     使用者沒選過節點時用清單的全域預設（cdnListMeta.defaultHost＝OTHER 的第一個）。頁面打開時請 background 檢查新版本。
 */
(function () {
  "use strict";
  var CFG_KEY = "__CDN_SWITCHER_CFG__";
  var DEFAULTS = {
    enabled: true,
    cdnHost: "", // 沒選過＝節點清單的全域預設（cdnListMeta.defaultHost）
    autoFallback: true,
    showDebug: false,
    videoEnabled: true,
    liveEnabled: true,
    liveRoute: "ov",
    autoSpeedHosts: [],
    installTestPending: false,
    stVideoMb: 8,
    stVideoSec: 5
  };

  var latestDebug = null;
  var isTopFrame = window.top === window;

  // ---- 問題回報：日誌／採樣／快照 → background（單一寫入者，寫進 storage.session）----
  function toBackground(msg) { try { chrome.runtime.sendMessage(msg, function () { void chrome.runtime.lastError; }); } catch (e) {} }
  function journal(k, d) { toBackground({ type: "CDN_SWITCHER_JOURNAL", entry: { t: Date.now(), k: k, d: d || {} } }); }
  var lastSnapAt = 0;
  function maybeStoreSnapshot(payload) {
    var now = Date.now();
    if (now - lastSnapAt < 5000) return;
    lastSnapAt = now;
    toBackground({ type: "CDN_SWITCHER_SNAPSHOT", payload: payload, url: location.href.split(/[?#]/)[0] });
  }

  var latestAutoTest = null; // 自动优化节点的进度（autotest-start/progress/end；安装后那次或卡顿时）
  // 「优化中」最长显示多久：MAIN 依节点数算好送来（maxMs）；送来的值不合理就用这个上限，免得 bug 让遮罩一直关不掉
  var AUTOTEST_MAX_MS = 10 * 60 * 1000;
  var speedTest = { running: false, results: [], total: 0, error: null, title: "", qn: "", avail: null };
  var speedTestHosts = []; // hosts of the current video run (from the popup); live runs have none
  var LIVE_ROUTES = ["ov", "ovb", "cn", "cnb"];
  // Same shape main-hook.js derives live hosts from (LIVE_HOST_RE there): any domain suffix is allowed
  var LIVE_HOST_RE = /^((?:[a-z0-9]+--)?)(ov|cn)-gotcha(\d+)(b?)(\.[a-z0-9.-]+)$/i;
  function isOwnSpeedtestRow(row) {
    if (typeof row.host !== "string") return false;
    if (row.route) return LIVE_ROUTES.indexOf(row.route) >= 0 && LIVE_HOST_RE.test(row.host);
    return speedTestHosts.indexOf(row.host) >= 0;
  }
  // "install" auto test: armed only when storage (which the page cannot write) says one is pending
  // at the time autotest-start arrives; a forged autotest-done with reason "install" is otherwise ignored.
  var installTestArmed = false;

  function pushConfig(cfg) {
    try { window.localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) {}
    try { window.postMessage({ __cdnSwitcher: 1, dir: "config", payload: cfg }, "*"); } catch (e) {}
  }

  function loadAndPush() {
    try {
      var keys = {}; for (var k0 in DEFAULTS) keys[k0] = DEFAULTS[k0];
      keys.cdnListMeta = null;
      chrome.storage.local.get(keys, function (items) {
        var cfg = {};
        for (var k in DEFAULTS) cfg[k] = items[k] === undefined ? DEFAULTS[k] : items[k];
        var meta = items.cdnListMeta;
        if (!cfg.cdnHost) cfg.cdnHost = (meta && meta.defaultHost) || "";
        // 沒有節點清單（第一次安裝還沒拿到、或更新後還沒拿到）＝擴充不啟用
        if (!meta || !meta.defaultHost || !cfg.cdnHost) cfg.enabled = false;
        if (!cfg.cdnHost) delete cfg.cdnHost; // main-hook 不收空的節點（會整份設定都不收），不送就沿用它的佔位值，反正 enabled 是 false
        pushConfig(cfg);
      });
    } catch (e) {}
  }

  // MAIN world 拿不到 chrome.i18n（页面 context 无扩充 API），toast / debug 叠层要用的
  // 语系文案由这里（ISOLATED world）代查後推过去，作法与 cfg 相同（localStorage + postMessage）。
  // 开局推一次；使用者在 popup 切换语言（uiMsgs 变更）时会再推一次。
  var MSGS_KEY = "__CDN_SWITCHER_MSGS__";
  var MSG_KEYS = [
    "mhToastAutoSwitched", "mhToastAllFailed", "mhToastReloadBackup", "mhToastClose",
    "mhCdnTargetOriginal", "mhCdnTargetBackup", "mhToastLiveFallback", "mhToastSwitched",
    "liveRouteOv", "liveRouteOvB", "liveRouteCn", "liveRouteCnB"
  ];
  // 使用者在 popup 進階設定選了語言時，popup 會把該語系的整份文案存在 storage 的 uiMsgs，優先用它
  function localMsg(uiMsgs, k) { return (uiMsgs && uiMsgs[k]) || chrome.i18n.getMessage(k); }
  function pushMessages() {
    function push(uiMsgs) {
      var msgs = {};
      try { MSG_KEYS.forEach(function (k) { msgs[k] = localMsg(uiMsgs, k); }); } catch (e) {}
      try { window.localStorage.setItem(MSGS_KEY, JSON.stringify(msgs)); } catch (e) {}
      try { window.postMessage({ __cdnSwitcher: 1, dir: "messages", payload: msgs }, "*"); } catch (e) {}
    }
    try { chrome.storage.local.get({ uiMsgs: null }, function (items) { push(items.uiMsgs); }); } catch (e) { push(null); }
  }

  // 启动即同步一次
  loadAndPush();
  pushMessages();

  // 安装时没查到 IP（国家还没选、安装后的优化还没跑）：请 background 再查一次，第一支影片的优化就能用所在国家的清单
  // （查不到的话 background 安装时已经先放了「其他地区」的清单）
  if (isTopFrame) {
    try {
      chrome.storage.local.get({ countryAutoDone: false, installTestPending: false }, function (items) {
        if (!items.countryAutoDone && items.installTestPending) toBackground({ type: "CDN_SWITCHER_SELECT_COUNTRY" });
      });
    } catch (e) {}
    // 節點清單有沒有新版本（background 6 小時內不重問；還沒有清單時會馬上再試）
    toBackground({ type: "CDN_SWITCHER_CDN_LIST" });
  }

  // 測速工具（CDNSpeedTest.exe）測完後會用瀏覽器開 https://www.bilibili.com/#cdnsw-import=1.<host>,<host>…，
  // 這裡把節點交給 background 接到「自訂節點列表」後面（background 只收節點清單裡有的節點），
  // 拿掉網址上的 hash 免得重新整理又匯入一次，再在頁面上提示結果
  var IMPORT_RE = /^#cdnsw-import=1\.([a-z0-9.,-]+)$/i;
  function importFromHash() {
    if (window.top !== window) return;
    var m = IMPORT_RE.exec(location.hash || "");
    if (!m) return;
    try { history.replaceState(null, "", location.pathname + location.search); } catch (e) {}
    var hosts = m[1].toLowerCase().split(",").filter(Boolean).slice(0, 50);
    try {
      chrome.runtime.sendMessage({ type: "CDN_SWITCHER_IMPORT_CUSTOM", hosts: hosts }, function (r) {
        void chrome.runtime.lastError;
        var key = !r || !r.ok ? "importToastFail" : r.added ? "importToastOk" : "importToastNone";
        try {
          chrome.storage.local.get({ uiMsgs: null }, function (items) {
            showImportToast(localMsg(items.uiMsgs, key).replace("{n}", r && r.added));
          });
        } catch (e) {}
      });
    } catch (e) {}
  }
  function showImportToast(text) {
    function show() {
      var el = document.createElement("div");
      el.textContent = text;
      el.style.cssText = "position:fixed;left:50%;top:24px;transform:translateX(-50%);z-index:2147483647;" +
        "max-width:min(560px,90vw);padding:14px 20px;border-radius:10px;background:#00AEEC;color:#fff;" +
        "font:600 15px/1.5 -apple-system,'Segoe UI','Microsoft JhengHei',sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);cursor:pointer";
      el.addEventListener("click", function () { el.remove(); });
      document.documentElement.appendChild(el);
      setTimeout(function () { el.remove(); }, 15000);
    }
    if (document.body) show(); else document.addEventListener("DOMContentLoaded", show);
  }
  importFromHash();
  // 已經停在 B 站頁面時再開匯入網址（例如 iPad 掃 QR code 開在同一個分頁），只換 hash、頁面不會重新載入，靠 hashchange 接
  window.addEventListener("hashchange", importFromHash);

  // chrome.storage 变更 → 重新推送
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      loadAndPush();
      if (changes.uiMsgs) pushMessages();
    });
  } catch (e) {}

  // 收 MAIN 的 debug 回报（自动回退是 MAIN world 内部的静默行为，不写回 storage）
  window.addEventListener("message", function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d.__cdnSwitcher !== 1) return;
    if (d.dir === "debug") { latestDebug = d.payload || null; if (isTopFrame && latestDebug) maybeStoreSnapshot(latestDebug); return; }
    if (d.dir === "journal" && d.payload && isTopFrame) { toBackground({ type: "CDN_SWITCHER_JOURNAL", entry: d.payload }); return; }
    if (d.dir === "sample" && d.payload && isTopFrame) { toBackground({ type: "CDN_SWITCHER_SAMPLE", row: d.payload }); return; }
    // 自动优化节点（main-hook 的 reason "install"／"stall"）：进度给 popup 显示「当前节点速度不佳，优化中」；
    // 安装后那次一开始就把旗标清掉，之后不论结果都不再测
    if (d.dir === "autotest-start" && d.payload) {
      var maxMs = Number(d.payload.maxMs);
      latestAutoTest = { running: true, reason: d.payload.reason || "", total: d.payload.total || 0, done: 0,
        startedAt: Date.now(), maxMs: maxMs > 0 && maxMs < AUTOTEST_MAX_MS ? maxMs : AUTOTEST_MAX_MS };
      if (d.payload.reason === "install") {
        try {
          chrome.storage.local.get({ installTestPending: false }, function (items) {
            installTestArmed = !!items.installTestPending;
            if (items.installTestPending) chrome.storage.local.set({ installTestPending: false });
          });
        } catch (e) {}
      }
      return;
    }
    if (d.dir === "autotest-progress" && d.payload) { if (latestAutoTest) latestAutoTest.done = d.payload.done || 0; return; }
    if (d.dir === "autotest-end") { if (latestAutoTest) latestAutoTest.running = false; return; }
    if (d.dir === "speedtest-meta" && d.payload) {
      speedTest.title = d.payload.title || "";
      speedTest.qn = d.payload.qn || "";
      return;
    }
    if (d.dir === "speedtest-avail" && d.payload) { speedTest.avail = d.payload.avail || null; return; }
    if (d.dir === "speedtest-progress" && d.payload) {
      // Page-forgeable as well; results only feed the popup's list, but still refuse rows that
      // are not part of the run we started (video: the host list from the popup; live: a known route on a CDN host).
      if (!isOwnSpeedtestRow(d.payload)) return;
      // 直播测速一条线路会分几次回报（起播 → 持续），以 route 合并成同一笔；点播测速没有 route，照旧依序追加
      var idx = -1;
      if (d.payload.route) for (var i = 0; i < speedTest.results.length; i++) if (speedTest.results[i].route === d.payload.route) { idx = i; break; }
      if (idx >= 0) { for (var k in d.payload) speedTest.results[idx][k] = d.payload[k]; }
      else speedTest.results.push(d.payload);
      return;
    }
    // 自动优化测完：把选到的节点存成使用者选的节点（storage 变更会再推回 MAIN，由它做播放器内重载）。
    // 存之前再确认一次设定：期间使用者关掉了开关、或自己换了节点（cdnHost 已不是开测时的 from），就不覆盖。
    // 安装后的那一次（reason "install"）不看开关，但要先经过上面的 installTestArmed；卡顿时那次（"stall"）要开着「速度不佳时自动优化节点」
    // Security: any script running in the page context (bilibili's own, third-party SDKs, other
    // extensions) can post a forged "autotest-done", and whatever host we store here is applied to
    // every segment request in every tab from then on. Every condition below reads storage, which
    // the page cannot write: the host must be in autoSpeedHosts (the list the test was asked to
    // measure), "install" needs a real pending test, "stall" needs autoFallback on, and videoEnabled
    // is never touched from here (auto tests only run while video override is on anyway).
    if (d.dir === "autotest-done" && d.payload && typeof d.payload.host === "string") {
      var p = d.payload;
      journal("ui.speedtest", { phase: "apply", kind: "auto-" + (p.reason || ""), host: p.host, from: p.from });
      var install = p.reason === "install" && installTestArmed;
      if (p.reason === "install") installTestArmed = false;
      try {
        chrome.storage.local.get({ autoFallback: DEFAULTS.autoFallback, cdnHost: DEFAULTS.cdnHost, autoSpeedHosts: [], cdnListMeta: null }, function (items) {
          if (!Array.isArray(items.autoSpeedHosts) || items.autoSpeedHosts.indexOf(p.host) < 0) return;
          if ((items.cdnHost || (items.cdnListMeta && items.cdnListMeta.defaultHost) || "") !== p.from) return;
          if (!install && !(p.reason === "stall" && items.autoFallback)) return;
          chrome.storage.local.set({ cdnHost: p.host });
        });
      } catch (e) {}
      return;
    }
    if (d.dir === "speedtest-done") {
      speedTest.running = false;
      speedTest.error = (d.payload && d.payload.error) || null;
      // 手動測速結束：記前三名（影片：bps；直播：起播毫秒）與錯誤，回報頁用來判斷「節點是測速選錯的」還是「選對了但現在壞了」
      var rs = speedTest.results.slice().filter(function (r) { return r && !r.error; });
      rs.sort(function (a, b) { return (b.bps || 0) - (a.bps || 0) || ((a.startup && a.startup.avg) || 9e9) - ((b.startup && b.startup.avg) || 9e9); });
      journal("ui.speedtest", { phase: "done", kind: speedTest.total === 4 && rs.length && rs[0].route ? "live" : "video", tested: speedTest.results.length, total: speedTest.total, error: speedTest.error || "",
        top: rs.slice(0, 3).map(function (r) { return (r.route || (r.host || "").replace(/\.bilivideo\.(com|cn)$/i, "")) + ":" + (r.bps != null ? Math.round(r.bps / 1024) + "k" : Math.round((r.startup && r.startup.avg) || 0) + "ms"); }) });
      return;
    }
  });

  // 回应 popup 查询 / 测速指令。只由最上层 frame 回应：iPad Safari 送讯息时不能指定 frameId: 0（见 popup.js 的 sendToTop），
  // 会送到所有 frame，iframe 里的 bridge 不能抢着回应
  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!isTopFrame) return;
      if (msg && msg.type === "CDN_SWITCHER_GET_DEBUG") {
        // 顺便通知 MAIN：popup 开着了，直播间可以开始探测各线路是否存在（懒探测，见 main-hook.js）
        try { window.postMessage({ __cdnSwitcher: 1, dir: "debug-poll" }, "*"); } catch (e) {}
        // 超过最长时间还没收到 autotest-end（MAIN 卡住或讯息掉了）：当作已结束，popup 的遮罩就会关掉
        if (latestAutoTest && latestAutoTest.running && Date.now() - latestAutoTest.startedAt > latestAutoTest.maxMs) latestAutoTest.running = false;
        sendResponse({ debug: latestDebug, autoTest: latestAutoTest });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_RUN_SPEEDTEST") {
        // 一律直接开新一轮：MAIN world 若前一轮还在跑，runSpeedTest 自己会中断旧的再开始
        // （用 generation 计数器隔开新旧两轮的 continuation，见 main-hook.js）
        var hosts = Array.isArray(msg.hosts) ? msg.hosts : [];
        speedTestHosts = hosts.slice();
        speedTest = { running: true, results: [], total: hosts.length, error: null, title: speedTest.title, qn: speedTest.qn, avail: null };
        journal("ui.speedtest", { phase: "start", kind: "video", hosts: hosts.length });
        try { window.postMessage({ __cdnSwitcher: 1, dir: "speedtest-run", payload: { hosts: hosts, limits: msg.limits || null } }, "*"); } catch (e) {}
        sendResponse({ ok: true });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_RUN_LIVE_SPEEDTEST") {
        speedTestHosts = [];
        speedTest = { running: true, results: [], total: 4, error: null, title: speedTest.title, qn: speedTest.qn, avail: null };
        journal("ui.speedtest", { phase: "start", kind: "live" });
        try { window.postMessage({ __cdnSwitcher: 1, dir: "livetest-run", payload: { limits: msg.limits || null } }, "*"); } catch (e) {}
        sendResponse({ ok: true });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_STOP_AUTOTEST") {
        try { window.postMessage({ __cdnSwitcher: 1, dir: "autotest-stop" }, "*"); } catch (e) {}
        sendResponse({ ok: true });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_STOP_SPEEDTEST") {
        if (speedTest.running) journal("ui.speedtest", { phase: "stop" });
        speedTest.running = false;
        try { window.postMessage({ __cdnSwitcher: 1, dir: "speedtest-stop" }, "*"); } catch (e) {}
        sendResponse({ ok: true });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_GET_SPEEDTEST") {
        sendResponse({ speedTest: speedTest });
        return true;
      }
      if (msg && msg.type === "CDN_SWITCHER_GET_DEBUG_FRESH") {
        // 回報頁要「此刻」的快照：先叫 MAIN flush，再把最新的一份回去（flush 經 postMessage 要下一個 tick 才到，稍等）
        try { window.postMessage({ __cdnSwitcher: 1, dir: "debug-flush" }, "*"); } catch (e) {}
        setTimeout(function () { sendResponse({ debug: latestDebug, url: location.href.split(/[?#]/)[0] }); }, 150);
        return true;
      }
    });
  } catch (e) {}

  // popup 开一条 "cdn-switcher-speedtest" 长连线来标记「测速页开着」；不论是按返回主动断线、
  // 还是直接关掉 popup（浏览器自动断线），content script 都会收到 onDisconnect → 立刻中止测速
  try {
    chrome.runtime.onConnect.addListener(function (port) {
      if (!isTopFrame || !port || port.name !== "cdn-switcher-speedtest") return;
      port.onDisconnect.addListener(function () {
        speedTest.running = false;
        try { window.postMessage({ __cdnSwitcher: 1, dir: "speedtest-stop" }, "*"); } catch (e) {}
      });
    });
  } catch (e) {}

  // Test seam: only the unit-test harness (test/helpers/load.mjs) defines __BCS_TEST__.
  if (globalThis.__BCS_TEST__ && typeof globalThis.__BCS_TEST__.register === "function") {
    globalThis.__BCS_TEST__.register("bridge", {
      IMPORT_RE: IMPORT_RE, importFromHash: importFromHash, DEFAULTS: DEFAULTS,
      speedTest: function () { return speedTest; }, latestDebug: function () { return latestDebug; }, latestAutoTest: function () { return latestAutoTest; }
    });
  }
})();
